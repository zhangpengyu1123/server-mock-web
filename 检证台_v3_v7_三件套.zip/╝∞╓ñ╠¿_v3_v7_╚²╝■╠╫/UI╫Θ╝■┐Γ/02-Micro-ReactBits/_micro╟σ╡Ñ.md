# Micro 微交互组件清单（从 react-bits 克隆抽取）

- 克隆来源：<https://github.com/DavidHDev/react-bits>（commit `43591e8b`）
- 线上分类页：<https://reactbits.dev/c/micro>（本目录 `_live-site/reactbits-c-micro.html` 为渲染快照）
- 本地组件数：**34** 个；官方 llms.txt 当前收录：**34** 个
- 每个组件 = 1 个 `.jsx` + 1 个同名 `.css`（组件内部 `import './X.css'`，复制两文件即可用）
- 抽取副本：`_micro-only/Micro/<组件名>/`（原样复制，未改动）；完整仓库仍在上一级目录

| # | 组件 | CLI / 目录 | 本地源码 | 文档 | 说明 |
| --- | --- | --- | --- | --- | --- |
| 1 | Bell Toggle | `BellToggle` | [BellToggle](_micro-only/Micro/BellToggle/) | [文档](https://www.reactbits.dev/micro/bell-toggle) | Pill toggle where a press rings the bell, crossfades the label and unfurls the pill |
| 2 | Branched Menu | `BranchedMenu` | [BranchedMenu](_micro-only/Micro/BranchedMenu/) | [文档](https://www.reactbits.dev/micro/branched-menu) | Collapsible menu that branches each section from a trunk and traces a line to your pick |
| 3 | Call Chip | `CallChip` | [CallChip](_micro-only/Micro/CallChip/) | [文档](https://www.reactbits.dev/micro/call-chip) | Tool-call chip whose fill wipes across as a live timer ticks, ending green or shaking red |
| 4 | Code Slots | `CodeSlots` | [CodeSlots](_micro-only/Micro/CodeSlots/) | [文档](https://www.reactbits.dev/micro/code-slots) | One-time code input whose digits spring into their slots, with paste and SMS autofill |
| 5 | Comet Dial | `CometDial` | [CometDial](_micro-only/Micro/CometDial/) | [文档](https://www.reactbits.dev/micro/comet-dial) | Tick-ring dial you flick by angle, with a comet that streaks behind the lit head |
| 6 | Dodge Field | `DodgeField` | [DodgeField](_micro-only/Micro/DodgeField/) | [文档](https://www.reactbits.dev/micro/dodge-field) | Wrapper that makes any child dodge the pointer until it relents and glides home |
| 7 | Flip Card | `FlipCard` | [FlipCard](_micro-only/Micro/FlipCard/) | [文档](https://www.reactbits.dev/micro/flip-card) | Two-faced card that flips in 3D on a click, drag or flick and settles on a spring |
| 8 | Folder Float | `FolderFloat` | [FolderFloat](_micro-only/Micro/FolderFloat/) | [文档](https://www.reactbits.dev/micro/folder-float) | Folder whose notes spring out into a floating cloud when it opens on hover or press |
| 9 | Fuse Button | `FuseButton` | [FuseButton](_micro-only/Micro/FuseButton/) | [文档](https://www.reactbits.dev/micro/fuse-button) | Action button whose done state carries an undo on a burning fuse |
| 10 | Glide Select | `GlideSelect` | [GlideSelect](_micro-only/Micro/GlideSelect/) | [文档](https://www.reactbits.dev/micro/glide-select) | Select chip whose menu pops from its corner and whose highlight glides between rows |
| 11 | Hold Button | `HoldButton` | [HoldButton](_micro-only/Micro/HoldButton/) | [文档](https://www.reactbits.dev/micro/hold-button) | Hold-to-confirm button whose liquid fill rises while pressed and snaps back if you let go |
| 12 | Jelly Radio | `JellyRadio` | [JellyRadio](_micro-only/Micro/JellyRadio/) | [文档](https://www.reactbits.dev/micro/jelly-radio) | Radio group of chips where the chosen one swells and barges its neighbours outward |
| 13 | Lattice Loader | `LatticeLoader` | [LatticeLoader](_micro-only/Micro/LatticeLoader/) | [文档](https://www.reactbits.dev/micro/lattice-loader) | Agent status row with a lattice of cells that brighten in a wave beside a live stopwatch |
| 14 | Paper Crumple | `PaperCrumple` | [PaperCrumple](_micro-only/Micro/PaperCrumple/) | [文档](https://www.reactbits.dev/micro/paper-crumple) | An image that crumples into a textured 3D sheet while you hold and drag it |
| 15 | Peek Rating | `PeekRating` | [PeekRating](_micro-only/Micro/PeekRating/) | [文档](https://www.reactbits.dev/micro/peek-rating) | Star rating that lifts a wave of stars up to the pointer, then commits with a pop on click |
| 16 | Prompt Bar | `PromptBar` | [PromptBar](_micro-only/Micro/PromptBar/) | [文档](https://www.reactbits.dev/micro/prompt-bar) | Chat composer with @ sources, / commands, a model picker, dictation and attachments |
| 17 | Pulse Heart | `PulseHeart` | [PulseHeart](_micro-only/Micro/PulseHeart/) | [文档](https://www.reactbits.dev/micro/pulse-heart) | Like button that contracts to a dot, flips colour and pulses back as the count ticks over |
| 18 | Refine Frame | `RefineFrame` | [RefineFrame](_micro-only/Micro/RefineFrame/) | [文档](https://www.reactbits.dev/micro/refine-frame) | Media frame that steps an image through generation stages without any layout shift |
| 19 | Rubber Segment | `RubberSegment` | [RubberSegment](_micro-only/Micro/RubberSegment/) | [文档](https://www.reactbits.dev/micro/rubber-segment) | Segmented control whose rubber thumb stretches across the gap and squashes into place |
| 20 | Scrub Field | `ScrubField` | [ScrubField](_micro-only/Micro/ScrubField/) | [文档](https://www.reactbits.dev/micro/scrub-field) | Number chip you drag to scrub, with rubber-band limits and click to type |
| 21 | Shredder | `Shredder` | [Shredder](_micro-only/Micro/Shredder/) | [文档](https://www.reactbits.dev/micro/shredder) | A list with a paper shredder at the bottom that cuts dragged rows into curling strips |
| 22 | Slide Commit | `SlideCommit` | [SlideCommit](_micro-only/Micro/SlideCommit/) | [文档](https://www.reactbits.dev/micro/slide-commit) | Slide-to-confirm handle that spins while your action runs and unfurls into a done pill |
| 23 | Sling Button | `SlingButton` | [SlingButton](_micro-only/Micro/SlingButton/) | [文档](https://www.reactbits.dev/micro/sling-button) | Send button you pull back like a slingshot and release to fire |
| 24 | Slosh Gauge | `SloshGauge` | [SloshGauge](_micro-only/Micro/SloshGauge/) | [文档](https://www.reactbits.dev/micro/slosh-gauge) | Tank gauge whose liquid chases the value, tilts as it moves and splashes when it fills |
| 25 | Spring Check | `SpringCheck` | [SpringCheck](_micro-only/Micro/SpringCheck/) | [文档](https://www.reactbits.dev/micro/spring-check) | Checkbox row where one spring fills the box, draws the tick and strikes through the label |
| 26 | Squish Switch | `SquishSwitch` | [SquishSwitch](_micro-only/Micro/SquishSwitch/) | [文档](https://www.reactbits.dev/micro/squish-switch) | Switch whose thumb stretches with speed and squashes against the end when you flick it |
| 27 | Status Mark | `StatusMark` | [StatusMark](_micro-only/Micro/StatusMark/) | [文档](https://www.reactbits.dev/micro/status-mark) | Agent task status glyph that morphs from an idle ring to a progress arc, then a check |
| 28 | Swipe Row | `SwipeRow` | [SwipeRow](_micro-only/Micro/SwipeRow/) | [文档](https://www.reactbits.dev/micro/swipe-row) | List row that swipes open to reveal actions and deletes on a full swipe |
| 29 | Swipe Toast | `SwipeToast` | [SwipeToast](_micro-only/Micro/SwipeToast/) | [文档](https://www.reactbits.dev/micro/swipe-toast) | Toast that swipes down to dismiss and burns a thin fuse for its remaining time |
| 30 | Tear Ticket | `TearTicket` | [TearTicket](_micro-only/Micro/TearTicket/) | [文档](https://www.reactbits.dev/micro/tear-ticket) | Ticket whose perforated stub tears off by hand, fibre by fibre, and drops away |
| 31 | Thought Line | `ThoughtLine` | [ThoughtLine](_micro-only/Micro/ThoughtLine/) | [文档](https://www.reactbits.dev/micro/thought-line) | Reasoning trace header with a live clock that folds its steps into one line when done |
| 32 | Voice Pill | `VoicePill` | [VoicePill](_micro-only/Micro/VoicePill/) | [文档](https://www.reactbits.dev/micro/voice-pill) | Mic button that swells into a capsule of live equalizer bars and a timer while recording |
| 33 | Wake Slider | `WakeSlider` | [WakeSlider](_micro-only/Micro/WakeSlider/) | [文档](https://www.reactbits.dev/micro/wake-slider) | Thumbless range slider of thin bars where drag speed raises a wake behind the handle |
| 34 | Warm Tooltip | `WarmTooltip` | [WarmTooltip](_micro-only/Micro/WarmTooltip/) | [文档](https://www.reactbits.dev/micro/warm-tooltip) | Tooltip group where the first label waits, then its siblings open instantly while warm |

## 第三方依赖速查

| 依赖 | 用到的组件 |
| --- | --- |
| `motion/react` | BellToggle, CodeSlots, CometDial, DodgeField, FlipCard, JellyRadio, PromptBar, RubberSegment, ScrubField, SlideCommit, SlingButton, SpringCheck, SquishSwitch, StatusMark, SwipeRow, SwipeToast, TearTicket, ThoughtLine, WakeSlider, WarmTooltip |
| `@hugeicons/react + @hugeicons/core-free-icons` | BranchedMenu, CallChip, FuseButton, GlideSelect, PeekRating, PulseHeart, RefineFrame, VoicePill |
| `three` | PaperCrumple |
| `matter-js` | FolderFloat |
| `react/react-dom only` | HoldButton, LatticeLoader, Shredder, SloshGauge |
