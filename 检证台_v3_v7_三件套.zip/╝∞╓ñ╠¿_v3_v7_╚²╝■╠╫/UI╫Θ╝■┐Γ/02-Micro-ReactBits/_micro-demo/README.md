# Micro 本地运行验证 demo

目的：证明**拿下来的这份 Micro 源码本身能跑**——直接从上一级克隆
（`../src/content/Micro/`）import 组件，不复制、不修改原文件，用 Vite + React 19 渲染出来。

## 结果（已实测）

- `npm install`（72 个包）→ `npm run build` **成功**：`✓ 6485 modules transformed`，产出
  `dist/index.html` + `dist/assets/index-*.js`（431 KB / gzip 140 KB）+ `index-*.css`（40 KB）
- `npm run preview` 后浏览器打开，**13 个 Micro 组件全部正常渲染**：
  HoldButton、SpringCheck、SquishSwitch、BellToggle、FuseButton、JellyRadio、ScrubField、
  LatticeLoader、SloshGauge、CometDial、WarmTooltip、FlipCard、SwipeToast
- 截图：`preview-本地运行.png`（全页）
- `dist/` 已保留，可离线打开：
  ```bash
  node ../../_tools/serve.mjs dist 4400     # → http://127.0.0.1:4400/
  ```
  注意 `node_modules/` 未随包保留（125 MB 可再生），要重新跑 dev/build 请先 `npm install`。

## 怎么再跑一遍

```bash
npm install
npm run dev        # http://localhost:5173/
# 或
npm run build && npm run preview -- --port 4321
```

## 一个实现细节

组件源码在 `../src/content/Micro/`（克隆本体），从它所在目录向上找不到 `node_modules`，
所以 `vite.config.mjs` 把 `react`、`react-dom`、`motion`、`@hugeicons/*`
显式 alias 到本 demo 的依赖目录，这样"直接 import 克隆源码"也能构建。
你自己的项目里不需要这步，按官方方式（shadcn / jsrepo CLI，或复制 jsx+css）取组件即可。

## 依赖

`react@19`、`react-dom@19`、`motion@12`、`@hugeicons/react`、`@hugeicons/core-free-icons`
（另有 `vite` + `@vitejs/plugin-react` 作为构建依赖）。
本 demo 刻意避开了需要 `three` 的 `PaperCrumple` 和需要 `matter-js` 的 `FolderFloat`，
这两个组件的依赖情况见 `../_micro清单.md` 末尾的依赖速查表。
