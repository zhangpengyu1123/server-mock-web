import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const nm = (pkg) => path.join(here, 'node_modules', pkg);

// 组件源码在 ../src/content/Micro/ 下（克隆本体），它自己所在目录往上找不到 node_modules，
// 所以把这些裸包名显式指向本 demo 的依赖，保证「直接 import 克隆源码」也能构建。
const alias = [
  { find: '@hugeicons/react', replacement: nm('@hugeicons/react') },
  { find: '@hugeicons/core-free-icons', replacement: nm('@hugeicons/core-free-icons') },
  { find: 'motion', replacement: nm('motion') },
  { find: 'react-dom', replacement: nm('react-dom') },
  { find: 'react', replacement: nm('react') },
];

export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: { alias },
  server: {
    fs: { allow: ['..'] },
  },
});
