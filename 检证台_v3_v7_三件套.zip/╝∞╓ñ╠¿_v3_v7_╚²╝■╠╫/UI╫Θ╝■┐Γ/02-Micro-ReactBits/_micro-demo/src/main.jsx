// Micro 微交互组件 · 本地运行验证 demo
// 直接 import 上一级克隆里的组件源码（../../src/content/Micro/...），不复制、不改动原文件，
// 验证的是「拿下来的这份代码本身能不能跑」。
import { createRoot } from 'react-dom/client';

import HoldButton from '../../src/content/Micro/HoldButton/HoldButton.jsx';
import FlipCard from '../../src/content/Micro/FlipCard/FlipCard.jsx';
import SpringCheck from '../../src/content/Micro/SpringCheck/SpringCheck.jsx';
import SquishSwitch from '../../src/content/Micro/SquishSwitch/SquishSwitch.jsx';
import BellToggle from '../../src/content/Micro/BellToggle/BellToggle.jsx';
import FuseButton from '../../src/content/Micro/FuseButton/FuseButton.jsx';
import JellyRadio from '../../src/content/Micro/JellyRadio/JellyRadio.jsx';
import ScrubField from '../../src/content/Micro/ScrubField/ScrubField.jsx';
import CometDial from '../../src/content/Micro/CometDial/CometDial.jsx';
import SloshGauge from '../../src/content/Micro/SloshGauge/SloshGauge.jsx';
import LatticeLoader from '../../src/content/Micro/LatticeLoader/LatticeLoader.jsx';
import SwipeToast from '../../src/content/Micro/SwipeToast/SwipeToast.jsx';
import WarmTooltip from '../../src/content/Micro/WarmTooltip/WarmTooltip.jsx';

import './demo.css';

const cells = [
  ['HoldButton', <HoldButton key="a">Hold to delete</HoldButton>],
  ['SpringCheck', <SpringCheck key="b" label="Ship the build" defaultChecked />],
  ['SquishSwitch', <SquishSwitch key="c" defaultChecked />],
  ['BellToggle', <BellToggle key="d" />],
  ['FuseButton', <FuseButton key="e" />],
  ['JellyRadio', <JellyRadio key="f" items={['Low', 'Medium', 'High']} />],
  ['ScrubField', <ScrubField key="g" />],
  ['LatticeLoader', <LatticeLoader key="h" />],
  ['SloshGauge', <SloshGauge key="i" />],
  ['CometDial', <CometDial key="j" />],
  [
    'WarmTooltip',
    <WarmTooltip key="k" content="Copy link" shortcut="⌘C">
      <button className="demo-btn" type="button">
        Hover me
      </button>
    </WarmTooltip>,
  ],
  [
    'FlipCard',
    <FlipCard
      key="l"
      width={250}
      height={170}
      front={<div className="flip-front">正面 · 点击翻转</div>}
      back={<div className="flip-back">Back</div>}
    />,
  ],
  [
    'SwipeToast',
    <SwipeToast key="m" inline title="File archived" description="Swipe down to dismiss" duration={100000} />,
  ],
];

function App() {
  return (
    <div className="page">
      <header>
        <h1>Micro 微交互组件 · 本地运行验证</h1>
        <p>
          组件源码来自 <code>02-Micro-ReactBits/src/content/Micro/</code>（react-bits 官方仓库克隆，commit
          <code>43591e8b</code>），本页未做任何改动，只负责把它们渲染出来。
        </p>
        <p>下方 13 个组件全部可交互：按住、点击、拖拽、悬停试试。</p>
      </header>
      <div className="grid">
        {cells.map(([name, node]) => (
          <section className="cell" key={name}>
            <div className="name">{name}</div>
            <div className="body">{node}</div>
          </section>
        ))}
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
