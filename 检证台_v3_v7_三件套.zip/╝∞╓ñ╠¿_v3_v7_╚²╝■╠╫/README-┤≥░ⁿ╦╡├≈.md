# 打包说明 · 检证台 × 三件套

本包 = **两版前台设计（V7 / V3）** + **你列出的三件套（Shaders / Micro / oil-ui）**。
全部离线可跑：零依赖、不联网、不引外部字体与 CDN。

打包时间：2026-10-16 · 打包自 `Server-Mock-Web` 工作区

---

## 一、先看什么

```bash
cd 检证台_v3_v7_三件套
node serve.mjs                 # → http://127.0.0.1:4500/
```

打开 `http://127.0.0.1:4500/` 就是**包导航页**，五件东西都能直接点开。
换端口：`node serve.mjs . 4600`（第二个参数是服务目录，第三个是端口）。

> 为什么必须起服务：V3/V7 是 `../_shared/*.js` 的相对引用，`file://` 直开会被浏览器拦；
> 组件库的离线快照也需要静态服务。

---

## 二、包内容

| # | 目录 | 干什么的 | 技术形态 | 动效占比 | 入口 |
| --- | --- | --- | --- | --- | --- |
| 1 | `mock-platform/v7-swiss-bench/` | **V7 检证台（瑞士版）**：mock 工作台前台 | 纯前台（静态 HTML/CSS/JS，无构建） | 由 `MP.btn` 技能预设驱动 | `/mock-platform/v7-swiss-bench/` |
| 2 | `mock-platform/v3-rhine-lab/` | **V3 莱茵生命 · 临床档案**：同一批数据的另一种视觉语言 | 纯前台（同上） | 同上 | `/mock-platform/v3-rhine-lab/` |
| 3 | `mock-platform/_shared/` | V3/V7 共用的数据层、规则引擎、动效、微交互、按钮动效 | 纯前端模块（IIFE，挂 `window.MP`） | 动效原语在此 | — |
| 4 | `UI组件库/01-Shaders-WebGPU/` | 200+ 可直接使用的 WebGPU 网页特效组件 | 纯前台（浏览器 WebGPU）；CLI 会连 shaders.com 账号服务 | **100% 动效/特效** | `/_live-site/shaders.com-home.html`（离线快照） |
| 5 | `UI组件库/02-Micro-ReactBits/` | 30+ 免费可自定义的 React 动效组件（微交互 / 背景 / 文本） | 纯前台（唯一"服务端"是静态资源 worker） | 大半是动效，另有真组件 | `/_micro-demo/dist/index.html`（**已构建，离线可跑**） |
| 6 | `UI组件库/03-oil-ui/` | 设计方向、审美判断、评审 | 不是代码库，是 Agent Skill（文本流程 + 可选脚本） | 明确不管动效实现 | `/SKILL.md`（纯文本，服务会当文本送出） |

### 来源与许可（保留出处）

| 目录 | 上游 | commit | 许可 |
| --- | --- | --- | --- |
| `01-Shaders-WebGPU` | https://github.com/shader-effects-inc/shaders | `81fd4ec` | MIT |
| `02-Micro-ReactBits` | https://github.com/DavidHDev/react-bits | `43591e8b` | MIT **+ Commons Clause**（不得把组件本身当商品转售） |
| `03-oil-ui` | https://github.com/oil-oil/oil-ui | `1640b36` | MIT |

> V3/V7 的视觉语言参考过莱茵生命相关开源仓库（博客主题 / 音乐台 / RhineLabUI）的**色值、字体策略与排版规则**，
> 只取设计参数，**未使用任何素材文件或官方 logo**（徽标为自绘 SVG）。

---

## 三、体量

```
合计 3662 文件 · 约 51.9 MB（未压缩）
  mock-platform/_shared            7 文件   0.12 MB
  mock-platform/v3-rhine-lab       4 文件   0.19 MB
  mock-platform/v7-swiss-bench     6 文件   0.16 MB
  UI组件库/01-Shaders-WebGPU    1222 文件  17.49 MB
  UI组件库/02-Micro-ReactBits   2379 文件  30.71 MB
  UI组件库/03-oil-ui              42 文件   3.27 MB
```

---

## 四、刻意排除的东西（以及为什么）

| 排除项 | 体积 | 原因 |
| --- | --- | --- |
| 各仓库的 `.git/` | 02 约 360 MB、01 约 8 MB、03 约 3 MB | 打包用不到历史；出处与 commit 已记在上表，需要时 `git clone` 后 `git checkout <commit>` 即可 |
| `02-Micro-ReactBits/public/` | **343 MB** | 这是上游站点自己的媒体资源（视频/大图），只有"跑整站 dev"才需要；组件源码与离线 demo 都在包里 |
| `node_modules/`、`dist/` 等构建缓存 | — | 可通过 `npm install` 复现；**例外**：`02/_micro-demo/dist/` 我保留了，因为它是已验证可离线运行的成品 demo |

需要**完整镜像**（含 `.git` 与 `public/`，约 780 MB）的话说一声，我按同样规则再打一个。

---

## 五、V3 / V7 是什么关系

两版**共用同一份 `_shared/`**：同一批数据、同一套响应规则引擎、同一套动效与微交互原语。
差异 100% 来自视觉与布局：

| | V3 莱茵生命（PRTS） | V7 检证台（瑞士版） |
| --- | --- | --- |
| 布局 | 顶部编号导航 + 检定档案式双栏 | 母线 + **横向信号链** + 仪器抽屉 + 监视器 + **审计带** |
| 语言 | 六边 / 菱形 / 斜纹 / 左侧色条 | 白底 #FAFAFA · 近黑 #18181B · 信号蓝 #0B63F6 · 细规则线 · 宋体巨号 |
| 主题 | 档案亮 / 终端暗 | 白昼 / 墨夜 |
| 签名交互 | 检定档案、PRTS 终端 | **信号珠沿链流动** · **可回放审计带（时间机器）** · **人机交互闸门** |

六个界面（Mock 管理 / Mock 流程 / 网元管理 / 网元管理平台 / 生命周期平台 / 虚层管理平台）两版都完整覆盖。

---

## 六、交付前的实测（在本工作区跑的，未在本包内重跑）

```
静态判据 oracle（功能逐条 + 动效 + 微交互 + 按钮动效 + 离线 + 语法）  7 个变体 7 通过 / 0 未通过
共享层单测（五类规则 / 动作 / 选择器 / 模拟器）                        24 通过 / 0 失败
浏览器 7 版 × 375/1440 × 六屏 = 84 次测量                             零横向滚动、pageerror = 0
V7 四档 375/768/1024/1440 × 六屏 = 24 次                              全过
```

本包内**未**重跑上述自动化（包内不含 `_verify/`）。若要在这个包里复跑，把工作区的 `_verify/` 一并拷进来即可。

---

## 七、已知边界

- **字体**：为保持离线，V3/V7 只用系统字体栈（MiSans/思源黑体/苹方/微软雅黑、宋体、等宽）。
  系统缺字会逐级回退，观感与设计规范原版略有差异；要完全还原本需自托管字体文件。
- **数据是前端模拟**：网元、软件包、日志都是种子数据 + 定时器模拟（`_shared/domain.js`）。
  接真实后端时替换 `domain.js` 的 actions 即可，两版视图层不用动。
- **`01-Shaders-WebGPU` 的 CLI** 会连 shaders.com 账号服务；本包只含源码与离线站点快照，不联外网。
- **`02-Micro-ReactBits`** 受 Commons Clause 限制：可以用于项目，但不能把组件本身当商品出售。
